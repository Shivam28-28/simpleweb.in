<?php
include 'header.php'
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Web Development Projects</title>
    <link rel="stylesheet" href="styles.css">
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;700&display=swap" rel="stylesheet">
    <style>
        body {
            font-family: 'Roboto', sans-serif;
            margin: 0;
            padding: 0;
            background: linear-gradient(270deg, #d4ede7f2, #ccc);
            color: #333;
            transition: filter 0.5s ease;
        }

        .blur {
            filter: blur(10px);
        }

        .container {
            display: flex;
            align-items: flex-start;
            padding: 40px;
            max-width: 1200px;
            margin: 20px auto;
            background: white;
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.1);
            border-radius: 10px;
            transition: transform 0.3s, box-shadow 0.3s;
            position: relative; /* For pseudo-element positioning */
        }

        .container:hover {
            transform: translateY(-5px);
            box-shadow: 0 15px 40px rgba(0, 0, 0, 0.2);
        }

        .container::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            border-radius: 10px;
            background: rgba(255, 255, 255, 0.5); /* Soft overlay */
            opacity: 0;
            transition: opacity 0.3s;
        }

        .container:hover::before {
            opacity: 1; /* Show overlay on hover */
        }

        .text-container {
            flex: 1;
            padding-left: 20px;
        }

        h1 {
            color: #2c3e50;
            font-size: 2.5em;
            margin-bottom: 10px;
            text-transform: uppercase; /* Make headings more prominent */
        }

        h2 {
            color: #34495e;
            font-size: 1.8em;
            margin-top: 20px;
            margin-bottom: 10px;
        }

        p {
            color: #555;
            line-height: 1.6;
            margin-bottom: 15px;
        }

        ul {
            margin: 10px 0;
            padding-left: 20px;
        }

        li {
            margin-bottom: 5px;
            color: #555;
            position: relative; /* For icon positioning */
            padding-left: 20px; /* Space for icon */
        }

        li::before {
            content: '✔'; /* Checkmark icon */
            position: absolute;
            left: 0;
            color: #2980b9; /* Icon color */
        }

        strong {
            color: #2c3e50;
        }

        .cta-button {
            display: inline-block;
            padding: 10px 20px;
            background-color: #2980b9;
            color: white;
            text-decoration: none;
            border-radius: 5px;
            transition: background-color 0.3s, transform 0.3s; /* Added transform for button */
            margin-top: 10px;
        }

        .cta-button:hover {
            background-color: #3498db;
            transform: scale(1.05); /* Slightly enlarge on hover */
        }

        @media (max-width: 768px) {
            .container {
                flex-direction: column;
                padding: 20px;
            }

            .text-container {
                padding-left: 0;
                padding-top: 20px;
            }

            h1 {
                font-size: 2em;
            }

            h2 {
                font-size: 1.5em;
            }
        }
    </style>
</head>
<body class="blur">
    <div class="container">
        <div class="text-container">
            <h1>Landing Page</h1>
            <p>In digital marketing, a landing page is a standalone web page, created specifically for a marketing or advertising campaign. It’s where a visitor “lands” after they click on a link in an email, or ads from Google, Bing, YouTube, Facebook, Instagram, Twitter, or similar places on the web.</p>
            <ul>
                <li><strong>Headline:</strong> Clear, engaging title that captures attention.</li>
                <li><strong>Call-to-Action (CTA):</strong> Buttons or forms to encourage user actions (e.g., sign up, buy, or download).</li>
                <li><strong>Visuals:</strong> Images or videos to grab attention and enhance the message.</li>
                <li><strong>Content:</strong> Brief, persuasive text explaining the offer or purpose.</li>
                <li><strong>User Focused:</strong> Minimal distractions for higher conversions.</li>
            </ul>
            <a href="https://unbounce.com/landing-page-articles/what-is-a-landing-page/" class="cta-button">Explore</a>
        </div>
    </div>

    <div class="container">
        <div class="text-container">
            <h1>Custom Website Development</h1>
            <p>Custom web development is the process of building a customized website that gives your brand a one-of-a-kind online experience. Developers will work on a software application, known as a content management system (CMS), that allows them to build and manage every aspect of a website.</p>
            <h2>Features:</h2>
            <ul>
                <li><strong>Responsive Design:</strong> The website will be optimized for all devices, ensuring a seamless user experience across desktops, tablets, and mobile phones.</li>
                <li><strong>Dynamic Content Management:</strong> The website will include a user-friendly CMS that allows the client to update content easily without technical knowledge.</li>
                <li><strong>SEO Optimization:</strong> The site will be built with SEO best practices in mind to enhance visibility on search engines.</li>
                <li><strong>Security Features:</strong> Implementation of security measures to protect user data and prevent unauthorized access.</li>
                <li><strong>Analytics Integration:</strong> Tools to track user behavior and website performance for ongoing improvements.</li>
            </ul>
            <h2>Timeline:</h2>
            <p>The project is expected to be completed within 8-12 weeks, with regular updates and feedback sessions to ensure alignment with the client's vision.</p>
            <a href="https://www.digitalsilk.com/web-development/custom-web-development/" class="cta-button">Explore</a>
        </div>
    </div>

    <div class="container">
        <div class="text-container">
            <h1>E-commerce Website Development</h1>
            <p>The objective of this project is to create a scalable and secure e-commerce platform that facilitates online product sales while providing a seamless user experience.</p>
            <h2>Features:</h2>
            <ul>
                <li><strong>User-Friendly Product Catalog:</strong> An intuitive catalog that allows users to browse and find products easily.</li>
                <li><strong>Shopping Cart and Checkout Process:</strong> A streamlined shopping cart and checkout experience to minimize cart abandonment.</li>
                <li><strong>Secure Payment Gateway Integration:</strong> Integration of secure payment options to protect user transactions.</li>
                <li><strong>User Accounts with Order Tracking:</strong> Users can create accounts to track their orders and manage their information.</li>
                <li><strong>Admin Panel for Inventory and Order Management:</strong> A backend system for administrators to manage products, orders, and customer information.</li>
                <li><strong>Search, Filters, and Product Recommendations:</strong> Advanced search capabilities and filters to enhance product discovery, along with personalized recommendations.</li>
                <li><strong>Responsive and Mobile-Friendly Design:</strong> A design that adapts to all devices, ensuring a great shopping experience on desktops, tablets, and smartphones.</li>
            </ul>
            <a href="https://www.shopify.com/blog/best-ecommerce-sites" class="cta-button">Explore</a>
        </div>
    </div>

    <div class="container">
        <div class="text-container">
            <h1>CMS Website Development</h1>
            <p>The objective of this project is to develop a robust Content Management System (CMS) to enable seamless content creation, management, and publishing with user-friendly features.</p>
            <h2>Features:</h2>
            <ul>
                <li><strong>Dynamic Content Creation/Editing Tools:</strong> Intuitive tools for users to create and edit content easily.</li>
                <li><strong>Role-Based Access Control:</strong> Different access levels for admins, editors, and viewers to ensure content security.</li>
                <li><strong>Media Management:</strong> Efficient management of media assets including image and video uploads.</li>
                <li><strong>SEO-Friendly Structure and Tools:</strong> Built-in features to optimize content for search engines.</li>
                <li><strong>Customizable Templates/Themes:</strong> Options to personalize the look and feel of the website.</li>
                <li><strong>Real-Time Content Preview and Publishing:</strong> Immediate preview of content changes before publishing.</li>
                <li><strong>Analytics Integration:</strong> Tools to track user engagement and website performance for continuous improvement.</li>
            </ul>
            <a href="https://blog.hubspot.com/blog/tabid/6307/bid/7969/what-is-a-cms-and-why-should-you-care.aspx" class="cta-button">Explore CMS</a>
        </div>
    </div>

    <script>
        window.onload = function() {
            setTimeout(function() {
                document.body.classList.remove('blur'); // Remove the blur class after 2 seconds
            }, 2000); // Adjust the delay time as needed (2000ms = 2 seconds)
        };
    </script>

</body>
</html>

<?php
include 'footer.php';
?>