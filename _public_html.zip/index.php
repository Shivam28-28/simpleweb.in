<?php
// index.php
include 'header.php'; // Correct way to include the header
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Website</title>
    <link rel="stylesheet" href="https://unpkg.com/swiper/swiper-bundle.min.css" />
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;700&display=swap" rel="stylesheet">
    <style>
   body {
    font-family: 'Roboto', sans-serif;
    margin: 0;
    padding: 0;
    background: linear-gradient(270deg, #d4ede7f2, #ccc); /* Light background color */
    color: #333; /* Default text color */
    transition: filter 0.5s ease; 
}
.blur {
            filter: blur(10px); /* Apply blur effect */
        }

/* Header Styles */
header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    background-color: linear-gradient(135deg, #2c3e50, #4ca1af);
    color: black;
    padding: 20px 20px;
}

.logo {
    font-size: 24px;
    font-weight: bold;
}

nav {
    display: flex;
    gap: 20px;
    margin-left: auto; /* Pushes nav to the right */
}

nav a {
    color: #2a6400b8;
    text-decoration: none;
    font-size: 18px;
    transition: color 0.3s;
}

nav a:hover {
    text-decoration: underline;
    color: #2a6406b8;
}

/* Slider Styles */
.slider-area {
    position: relative;
    overflow: hidden;
    margin-top: 20px; /* Adjust the value as needed for spacing */
}

.swiper-container {
    width: 100%;
    height: 80vh; /* Full height */
}

.swiper-slide {
    display: flex;
    justify-content: center;
    align-items: center;
    background-size: cover;
    background-position: center;
    color: white;
}

.slide-inner {
    text-align: center; /* Corrected text alignment */
    font-size: 56px;
    color: white;
    padding-right: 180px;
}

/* Banner Area Styles */
.container-image {
    position: relative; 
    margin: 80px auto; 
    display: flex; 
    justify-content: space-between; 
    flex-wrap: wrap;
    width: 90%; 
    max-width: 1110px; 
}

.container-image a {
    position: relative; 
    display: inline-block; 
    overflow: hidden;
    width: 48%; /* Adjust width for two columns */
    margin: 1%; /* Add margin for spacing */
    border-radius: 10px; /* Rounded corners for images */
    transition: transform 0.3s; /* Hide overflow to create a clean effect */
}

.container-image img {
    width: 100%; /* Make images responsive */
    height: auto; /* Maintain aspect ratio */
    max-width: 533px; /* Set a maximum width for each image */
    margin: 12px; /* Reduced padding on both sides */
    position: relative; /* Required for the overlay text */
    border-radius: 10px; /* Rounded corners for images */
    transition: transform 0.3s, box-shadow 0.3s, filter 0.3s; /* Transition for hover effects */
    border: 4px solid transparent; /* Initial border */
    box-shadow: 0 4px 15px rgba(0, 0, 0, 0.3); /* Subtle shadow */
}

.container-image img:hover {
    transform: scale(1.05); /* Slightly enlarge the image on hover */
    box-shadow: 0 0 20px rgba(255, 255, 255, 0.8), 0 0 30px rgba(255, 255, 255, 0.6); /* Add glow effect */
    filter: brightness(1.1); /* Brighten the image on hover */
    border: 4px solid rgba(255, 255, 255, 0.7); /* Add a white border on hover */
}

.overlay-text {
    position: absolute;
    bottom: 20%; /* Position it towards the bottom */
    left: 10%; /* Position it towards the left side */
    color: white; /* Text color */
    font-size: 24px; /* Font size */
    font-weight: bold; /* Make text bold */
    text-shadow: 2px 2px 4px rgba(0, 0, 0, 0.7); /* Optional shadow for better visibility */
    opacity: 0; /* Initially hidden */
    transition: opacity 0.3s; /* Smooth transition for opacity */
}

.container-image a:hover .overlay-text {
    opacity: 1; /* Show text on hover */
}

/* About Area Styles */
.about-area {
    display: flex;
    justify-content: center; /* Center horizontally */
    align-items: center; /* Center vertically */
    text-align: center; /* Center text */
    padding: 50px 0;
    background-color: #fff; /* White background for contrast */
    box-shadow: 0 4px 8px rgba(0, 0, 0, 0 .1); /* Subtle shadow */
    margin: 100px; /* Adjust padding as needed */
}

.section-title-area {
    max-width: 800px; /* Optional: Limit the width of the content */
    margin: 0 auto; /* Center the section title area */
}

.section-title {
    margin-bottom: 20px; /* Space between title and description */
}

.section-desc {
    font-size: 20px; /* Ensure the font size is consistent */
}

/* Hover Effect Styles */
.hover-effect a {
    position: relative; 
    display: inline-block; 
    overflow: hidden; /* Hide overflow to create a clean effect */
}

.hover-effect img {
    height: 400px; /* Existing height */
    width: auto; /* Existing width */
    max-width: 533px; /* Existing max width */
    margin: 12px; /* Existing margin */
    position: relative; /* Existing position */
    border-radius: 5px; /* Existing border radius */
    transition: transform 0.5s ease; /* Add transition for smooth movement */
}

.hover-effect a:hover img {
    transform: translateX(-20px); /* Move image to the left on hover */
}

.hover-effect .overlay-text {
    position: absolute;
    bottom: 20%; /* Position it towards the bottom */
    left: 10%; /* Position it towards the left side */
    color: white; /* Text color */
    font-size: 24px; /* Font size */
    font-weight: bold; /* Make text bold */
    text-shadow: 2px 2px 4px rgba(0, 0, 0, 0.7); /* Optional shadow for better visibility */
    opacity: 0; /* Initially hidden */
    transition: opacity 0.3s; /* Smooth transition for opacity */
}

.hover-effect a:hover .overlay-text {
    opacity: 1; /* Show text on hover */
}

/* Responsive Design */
* {
    box-sizing: border-box;

}

.column {
    float: left;
    width: 30%;
    padding: 0 10px;
}

.row {
    margin: 0 -5px;
}

.row:after {
    content: "";
    display: table;
    clear: both;
}

@media screen and (max-width: 600px) {
    .column {
        width: 100%;
        display: block;
        margin-bottom: 20px;
    }
}

/* Card Styles */
.card {
    text-align: center; /* Center text and image */
    border: 1px solid #ddd; /* Optional: add a border around the card */
    border-radius: 8px; /* Rounded corners for the card */
    padding: 30px 30px 10px 40px;
    margin: 80px; /* Margin outside the card */
    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1); /* Subtle shadow for depth */
    background-color: white; /* Set background color to white */
    color: black; /* Optional: Set text color to black for better contrast */
}
.row{
    padding-left: 120px;
    padding-top: 1;
}

.card-image {
    width: 150px; /* Set a fixed width for the image */
    height: auto; /* Maintain aspect ratio */
    border-radius: 50%; /* Make the image circular */
    margin: 40px 0; /* Space around the image */
}

/* Checklist Styles */
.checklist {
    margin: 10px; /* Remove default margin */
    padding: 10px; /* Remove default padding */
}

.checklist span {
    display: block; /* Make each span a block element to ensure proper alignment */
    position: relative;
    padding-left: 25px; /* Space for the checkmark */
    text-align: left; /* Align text to the left */
}

.checklist span::before {
    content: '\2713'; /* Unicode for checkmark */
    color: blue; /* Set the color of the checkmark */
    position: absolute;
    left: 0; /* Position it to the left */
    font-size: 16px; /* Adjust size if needed */
    line-height: 1.5; /* Adjust line height for spacing */
}

/* Button Styles */
.button-container {
    display: flex; /* Use flexbox for centering */
    justify-content: center; /* Center horizontally */
    margin: 20px 0; /* Optional: Add vertical spacing around the button */
}

.cta-button {
    background-color: #87CEEB; /* Light sky blue color */
    color: white; /* White text color for contrast */
    border: none; /* Remove default border */
    border-radius: 5px; /* Rounded corners */
    padding: 15px 30px; /* Add padding for size */
    font-size: 18px; /* Increase font size */
    cursor: pointer; /* Change cursor to pointer */
    transition: background-color 0.3s, transform 0.3s; /* Smooth transition for hover effects */
    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2); /* Subtle shadow for depth */
}

.cta-button:hover {
    background-color: #00BFFF; /* Darker sky blue on hover */
    transform: scale(1.05); /* Slightly enlarge the button on hover */
}
.title {
        color: #2c3e22; /* Replace with your desired color code */
    }
    
    .short-desc-2 {
        color: #34495e; /* Replace with your desired color code */
    }
    .overlay-text{
        color: #ddd;
    }
    </style>
</head>
<body class="blur">

<div class="slider-area">

<div class="swiper-container main-slider swiper-arrow with-bg_white">
    <div class="swiper-wrapper">
        <div class="swiper-slide animation-style-01" style="background-image: url('images/TOPweb_development_banner.svg');">
            <div class="slide-inner">
                <h2 class="title mb-3">Expert Web Solutions for Organizations that matter</h2>
                <p class="short-desc-2 font-size-20 mb-7">Specialize web development, hosting, and digital infrastructure services for B2B, non-profit organizations, and government entities.</p>
            </div>
        </div>
        <div class="swiper-slide animation-style-01" style="background-image: url('images/Web-Development-Price-BWS.png');">
            <div class="slide-inner">
                <h2 class="title mb-3">We bring your emotions to life in the virtual world</h2>
                <p class="short-desc-2 font-size-20 mb-7">Our website development focuses on crafting digital environments that resonate with your audience on a deeper level, blending design, technology.</p>
            </div>
        </div>
    </div>
    
    <div class="swiper-pagination with-bg d-md-none"></div>
</div>

</div>

<!-- Swiper JS -->
<script src="https://unpkg.com/swiper/swiper-bundle.min.js"></script>
<script>
    const swiper = new Swiper('.swiper-container', {
        direction: 'horizontal', // Default direction
        loop: true, // Enable looping
        autoplay: {
            delay: 3000, // Delay between transitions
            disableOnInteraction: false, // Continue autoplay after user interactions
        },
        pagination: {
            el: '.swiper-pagination',
            clickable: true,
        },
        navigation: {
            nextEl: '.swiper-button-next',
            prevEl: '.swiper-button-prev',
        },
    });

    console.log('Swiper initialized'); // Check if Swiper initializes
</script>


<div class="container-image">
    <a href="#" style="position: relative; display: inline-block;">
        <img src="images/TOPRATES.webp" alt="Top Rated Development" style="height: 530px; width: auto;"> <!-- Adjust the height as needed -->
        <span class="overlay-text"><h1>Top Rated</h1><p>"Experience top-rated web development that sets the standard for innovation and performance. Our expert team creates seamless, user-centric websites that not only meet your needs but exceed your expectations!"</p></span>
    </a>
    
    <a href="#" style="position: relative; display: inline-block;">
        <img src="images/BEST01.avif" alt="Best Quality Development" style="height: 530px; width: auto;">
        <span class="overlay-text"><h1>Best Quality</h1><p>"We deliver the best quality in web development, combining cutting-edge technology with creative design to build websites that are fast, secure, & visually stunning. Every project is crafted with precision to ensure top-tier performance"</p></span>
    </a>
</div>


<div class="about-area about-style-2 py-130">
    <div class="container">
        <div class="section-title-area style-01 pb-70">
            <h2 class="section-title with-border text-lg-center mb-0" style="font-size: 48px;">Comprehensive Web & <br>Digital Infrastructure Solutions</h2>
        </div>
    </div>

</div>

<div class="row">
    <div class="column">
    <div class="card">
    <p><i class=""></i></p>
    <img class="card-image" src="images/manlogo.png" alt="Man Logo">
    <h3>Website Development & Management</h3>
    <p style="color: #87CEEB;" class="checklist">
        <span>Custom website solutions</span><br>
        <span>Content management systems</span><br>
        <span>Performance optimization</span>
    </p>
</div>
    </div>

    <div class="column">
        <div class="card">
            <p><i class=""></i></p>
            <img class="card-image" src="images/infaimage01.png" alt="Man Logo">
            <h3>Digital Infrastructure</h3>
            <p style="color: #87CEEB;" class="checklist">
                <span>Professional DNS management</span><br>
                <span>Enterprise email solutions</span><br>
                <span>SSL certificate management</span>
            </p>
        </div>
    </div>
  
    <div class="column">
        <div class="card">
            <p><i class="fa fa-smile-o"></i></p>
            <img class="card-image" src="images/consul.png" alt="Man Logo">
            <h3>Web Technology &<br> Consulting</h3>
            <p class="checklist" style="color: #87CEEB;">
                <span>Website architecture planning</span><br>
                <span>Digital presence strategy</span><br>
                <span>Platform selection & migration</span>
            </p>
        </div>
    </div>
</div>
<div class="button-container">
    <button class="cta-button">Get Started</button>
</div>

<div class="container-image hover-effect">
    <a href="#" style="position: relative; display: inline-block;">
        <img src="images/IMG_20240909_202410_107.jpg" alt="Developer" style="height: 470px; width: auto;">
        <span class="overlay-text"><h1>Senior Developer <span> <br></span></h1><p>"Shivam Sharma"</p></span>
    </a>
    
    <a href="#" style="position: relative; display: inline-block;">
        <img src="images/003.avif" alt="Senior Developer" style="height: 470px; width: 495px;">
        <span class="overlay-text"><h1>Head Developer</h1><p>"Likun Pani"</p></span>
    </a>

    <a href="#" style="position: relative; display: inline-block;">
        <img src="images/002.avif" alt="Head Developer" style="height: 480px; width: 475px;">
        <span class="overlay-text"><h1>Head Developer</h1><p>"Nikhil Malviya"</p></span>
    </a>

    <a href="#" style="position: relative; display: inline-block;">
        <img src="images/002.avif" alt="Innovative Solutions" style="height: 500px; width: auto;">
        <span class="overlay-text"><h1>Developer</h1><p>"Kanika Sharma"</p></span>
    </a>
</div>

<div class="about-area about-style-2 py-130">
    <div class="container">
        <div class="section-title-area style-01 pb-70">
            <h2 class="section-title with-border text-lg-center mb-0" style="font-size: 48px;">Transforming Organizations <br>Through Web Technology</h2>
        </div>
    </div>
</div>

<div class="row">
    <div class="column">
    <div class="card">
    <p><i class=""></i></p>
    <img class="card-image" src="images/b2b.jpg" alt="Man Logo">
    <h3 style="color: #87CEEB;">B2B Website Transformation</h3>
    
</div>
    </div>

    <div class="column">
        <div class="card">
            <p><i class=""></i></p>
            <img class="card-image" src="images/non-profit.jpg" alt="Man Logo">
            <h3 style="color: #87CEEB;">Non-profit digital presence enhancement
            </h3>
           
        </div>
    </div>
  
    <div class="column">
        <div class="card">
            <p><i class=""></i></p>
            <img class="card-image" src="images/comp.png" alt="Man Logo">
            <h3 style="color: #87CEEB;">Government agency web compliance</h3>
           
        </div>
    </div>
</div>

<div class="row">
  <div class="column">
    <div class="card">
      <p><i class="fa fa-edit"></i></p>
      <h3>10+</h3>
      <p>Projects</p>
    </div>
  </div>

  <div class="column">
    <div class="card">
      <p><i class="fa fa-user"></i></p>
      <h3>6+</h3>
      <p>Happy Clients</p>
    </div>
  </div>
  
  <div class="column">
    <div class="card">
      <p><i class="fa fa-trophy"></i></p>
      <h3>7+</h3>
      <p>Success</p>
    </div>
  </div>
</div>
<script>
        window.onload = function() {
            setTimeout(function() {
                document.body.classList.remove('blur'); // Remove the blur class after 2 seconds
            }, 2000); // Adjust the delay time as needed (2000ms = 2 seconds)
        };
    </script>
</body>
</html>

<?php
include 'footer.php';
?>