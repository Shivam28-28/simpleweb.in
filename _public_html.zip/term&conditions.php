<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Terms and Conditions</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            line-height: 1.6;
            margin: 0;
            padding: 0;
            background-color: #f4f4f4;
        }
        .container {
            max-width: 800px;
            margin: 20px auto;
            padding: 20px;
            background: white;
            border-radius: 8px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
        }
        h1 {
            color: #333;
            text-align: center;
            margin-bottom: 20px;
        }
        h2 {
            color: #007BFF;
            margin-top: 20px;
        }
        p {
            color: #555;
            margin: 10px 0;
        }
        @media (max-width: 600px) {
            .container {
                padding: 15px;
            }
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Terms and Conditions</h1>
        <p>By accessing and using this website, you agree to the following terms and conditions regarding the submission of personal information:</p>

        <h2>1. Voluntary Submission of Information</h2>
        <p>You acknowledge that any information you provide on this website, whether through forms, surveys, or other input methods, is given voluntarily. You are not being forced or coerced by the website owner to submit any personal information.</p>

        <h2>2. No Obligation</h2>
        <p>You are under no obligation to submit any personal information unless specifically required for the purpose you are engaging with. The website owner does not require you to disclose any personal details unless necessary for a specific service or feature.</p>

        <h2>3. Privacy and Security</h2>
        <p>The website owner commits to safeguarding your information in accordance with applicable privacy laws. However, it is important to note that you are solely responsible for ensuring that the information you provide is accurate and up-to-date.</p>

        <h2>4. Rights to Modify or Delete Information</h2>
        <p>You retain the right to modify or delete any personal information you submit to the website, in accordance with the privacy policy and relevant regulations.</p>

        <h2>5. No Liability</h2>
        <p>The website owner shall not be held responsible for any consequences resulting from your voluntary submission of personal information, including but not limited to misuse, security breaches, or unauthorized access.</p>

        <p>By continuing to use this website, you confirm that you understand and agree to these terms.</p>

 </div>
</body>
</html> ⬤