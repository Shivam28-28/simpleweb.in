<?php
include 'header.php'
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Contact Us</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <style>
        body {
            font-family: 'Roboto', sans-serif;
            margin: 0;
            padding: 0;
            background: linear-gradient(270deg, #d4ede7f2, #ccc);
            color: #333;
            transition: filter 0.5s ease;
        }
        .blur {
            /* filter: blur(12px); */
        }
        .container {
            max-width: 800px;
            margin: 50px auto;
            background: #fff;
            border-radius: 10px;
            padding: 30px;
            box-shadow: 0 8px 16px rgba(0, 0, 0, 0.2);
            transition: all 0.3s ease;
            border: 1px solid rgb(0 196 255 / 55%);
        }
        .container:hover {
            transform: translateY(-5px);
            box-shadow: 0 12px 24px rgba(0, 0, 0, 0.3);
        }
        h1 {
            text-align: center;
            color: rgba(0, 0, 0, 0.3);
            margin-bottom: 30px;
            font-size: 2.5em;
        }
        .form-group {
            margin-bottom: 25px;
        }
        label {
            display: block;
            font-weight: bold;
            margin-bottom: 10px;
        }
        input, textarea {
            width: 100%;
            padding: 12px;
            border: 1px solid #ccc;
            border-radius: 10px;
            transition: border-color 0.3s;
        }
        input:focus, textarea:focus {
            border-color: #007bff;
            outline: none;
            box-shadow: 0 0 15px rgba(0, 123, 255, 0.5);
        }
        button {
            background-color: #00ffb8b0;
            color: #fff;
            padding: 12px 20px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 16px;
            transition: background-color 0.3s;
            width: 100%;
        }
        button:hover {
            background-color: #0056b3;
        }
        .success, .error {
            text-align: center;
            padding: 10px;
            margin-top: 10px;
            border-radius: 5px;
        }
        .success {
            background-color: #d4edda;
            color: #155724;
        }
        .error {
            background-color: #f8d7da;
            color: #721c24;
        }
        .contact-info {
            margin-top: 30px;
            padding: 20px;
            border-top: 3px solid #ccc;
            text-align: left;
        }
        .contact-info p {
            margin: 8px 0;
            text-align: left;
        }
        .contact-info .phone, .contact-info .address {
            font-weight: bold;
            text-align: ;
        }
        .social-icons {
            margin-top: 25px;
        }
        .social-icons a {
            margin: 0 10px;
            color: #007bff;
            font-size: 34px;
            text-decoration: none;
        }
        .social-icons a:hover {
            color: #0056b3;
        }
        @media (max-width: 600px) {
            h1 {
                font-size: 3em;
            }
        }
        /* Hide the default checkbox */
input[type="checkbox"] {
    display: none; /* Hide the default checkbox */
}

/* Custom checkbox style */
.checkbox-container {
    display: flex;
    align-items: center;
    cursor: pointer;
}

.checkbox {
    width: 20px; /* Custom width */
    height: 20px; /* Custom height */
    border: 2px solid #007bff; /* Border color */
    border-radius: 4px; /* Rounded corners */
    position: relative;
    margin-right: 10px; /* Space between checkbox and label */
    transition: background-color 0.3s, border-color 0.3s;
}

/* Checkmark style */
.checkbox:after {
    content: '';
    position: absolute;
    width: 6px;
    height: 12px;
    border: solid #007bff;
    border-width: 0 2px 2px 0;
    transform: rotate(45deg);
    top: 3px;
    left: 7px;
    opacity: 0; /* Initially hidden */
    transition: opacity 0.2s;
}

/* Show the checkmark when the checkbox is checked */
input[type="checkbox"]:checked + .checkbox {
    background-color: #007bff; /* Background color when checked */
    border-color: #007bff; /* Border color when checked */
}

input[type="checkbox"]:checked + .checkbox:after {
    opacity: 1; /* Show the checkmark */
}
        
    </style>
</head>
<body class="blur">
    <div class="container">
        <h1>Contact Us</h1>
        <?php
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $name = htmlspecialchars($_POST['name']);
            $email = htmlspecialchars($_POST['email']);
            $phone = htmlspecialchars($_POST['phone']); // Capture phone input
            $message = htmlspecialchars($_POST['message']);

            if (!empty($name) && !empty($email) && !empty($phone) && !empty($message) && filter_var($email, FILTER_VALIDATE_EMAIL)) {
                echo "<div class='success'>Thank you, $name! Your message has been sent.</div>";
            } else {
                echo "<div class='error'>Please fill out all fields correctly.</div>";
            }
        }
        ?>
      <form action="db.php" method="POST">
    <div class="form-group">
        <label for="name">Name</label>
        <input type="text" id="name" name="name" placeholder="Your Name" required>
    </div>
    <div class="form-group">
        <label for="email">Email</label>
        <input type="email" id="email" name="email" placeholder="Your Email" required>
    </div>
    <div class="form-group">
        <label for="phone">Phone</label>
        <input type="number" id="phone" name="phone" placeholder="Enter Your Number" required>
    </div>
    <div class="form-group">
        <label for="message">Message</label>
        <textarea id="message" name="message" rows="5" placeholder="Your Message" required></textarea>
    </div>
    <div class="form-group">
    <label class="checkbox-container">
        <input type="checkbox" id="terms" name="terms" required>
        <div class="checkbox"></div>
        I agree to the <a href="term&conditions.php" target="">Terms & Conditions</a>
    </label>
</div>

<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = htmlspecialchars($_POST['name']);
    $email = htmlspecialchars($_POST['email']);
    $phone = htmlspecialchars($_POST['phone']);
    $message = htmlspecialchars($_POST['message']);
    $terms = isset($_POST['terms']); // Check if the terms checkbox is checked

    if (!empty($name) && !empty($email) && !empty($phone) && !empty($message) && filter_var($email, FILTER_VALIDATE_EMAIL) && $terms) {
        echo "<div class='success'>Thank you, $name! Your message has been sent.</div>";
    } else {
        $error_message = "Please fill out all fields correctly.";
        if (!$terms) {
            $error_message .= " You must agree to the Terms & Conditions.";
        }
        echo "<div class='error'>$error_message</div>";
    }
}
?>


    <button type="submit">Send Message</button>
</form>

        
        <div class="contact-info">
    <h2>Contact Information</h2>
    
   <p class="address">
    <strong>Address 1:</strong> B 801 Arise Antlatis,Near Parmeshwar 07, Godrej Garden City, <br>
    Jagatpur, Ahmedabad - 382401, Gujarat, India
</p>
<p class="phone">Phone: +91 936 801 7732 | +91 824 907 0953</p>
</div>
        
        <div class="social-icons">
            <a href="#" class="fab fa-facebook-f"></a>
            <a href="#" class="fab fa-twitter"></a>
            <a href="#" class="fab fa-instagram"></a>
            <a href="#" class="fab fa-linkedin-in"></a>
        </div>
    </div>
    <script>
        window.onload = function() {
            setTimeout(function() {
                document.body.classList.remove('blur'); // Remove the blur class after 2 seconds
            }, 2000); // Adjust the delay time as needed (2000ms = 2 seconds)
        };
    </script>

</body>
</html>

<?php
include 'footer.php';
?>