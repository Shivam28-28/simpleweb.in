<?php
// Database connection
$servername = "localhost"; // or your server name
$username = "u164061975_root"; // your database username
$password = "~Y5x@7xK9=St"; // your database password
$dbname = "u164061975_contact_form"; // your database name

$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$messageResponse = ""; // Variable to hold the response message

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = htmlspecialchars($_POST['name']);
    $email = htmlspecialchars($_POST['email']);
    $phone = htmlspecialchars($_POST['phone']); // Capture phone input
    $message = htmlspecialchars($_POST['message']);

    // Validate inputs
    if (!empty($name) && !empty($email) && !empty($phone) && !empty($message) && filter_var($email, FILTER_VALIDATE_EMAIL)) {
        // Prepare and bind
        $stmt = $conn->prepare("INSERT INTO messages (name, email, phone, message) VALUES (?, ?, ?, ?)");
        $stmt->bind_param("ssss", $name, $email, $phone, $message);

        if ($stmt->execute()) {
            $messageResponse = "<div class='success'>Thank you, $name! Your message has been sent.</div>";
        } else {
            $messageResponse = "<div class='error'>There was an error sending your message. Please try again later.</div>";
        }

        $stmt->close();
    } else {
        $messageResponse = "<div class='error'>Please fill out all fields correctly.</div>";
    }
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Contact Form</title>
    <style>
        .success, .error {
            display: none;
            padding: 10px;
            margin: 10px 0;
        }
        .success {
            color: green;
        }
        .error {
            color: red;
        }
    </style>
</head>
<body>

<?php
if (!empty($messageResponse)) {
    echo $messageResponse;
    echo "<script>
        document.addEventListener('DOMContentLoaded', function() {
            var messageDiv = document.querySelector('.success, .error');
            if (messageDiv) {
                messageDiv.style.display = 'block';
                setTimeout(function() {
                    window.location.href = 'contact.php';
                }, 2000); // Redirect after 3 seconds
            }
        });
    </script>";
}
?>

</body>
</html>