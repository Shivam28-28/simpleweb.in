<?php
// index.php
include 'header.php'; // Correct way to include the header
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Content Container Example</title>
    <link rel="stylesheet" href="styles.css">
    <style>
       body {
    font-family: 'Roboto', sans-serif;
    margin: 0;
    padding: 0;
    background: linear-gradient(270deg, #d4ede7f2, #ccc); /* Light background color */
    color: #333; /* Default text color */
    transition: filter 0.5s ease;
}
       .blur {
            filter: blur(12px);
        }
       .content-container {
          max-width: 1200px;
          margin: 30px auto;
          padding: 30px;
          background-color: #fff;
          border-radius: 12px;
          box-shadow: 0 4px 20px rgba(0, 0, 0, 0.2);
          display: flex;
          align-items: center;
          transition: transform 0.2s;
       }

       .content-container:hover {
          transform: translateY(-5px);
       }

       .content-image {
          max-width: 46%;
          height: auto;
          margin-right: 30px;
          margin-top: 30px;
          border-radius: 8px;
          box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
       }

       .content-heading {
          font-size: 24px;
          color: #333;
          margin-bottom: 10px;
          font-family: 'Georgia', serif;
          transition: color 0.2s;
       }
       .content-heading-s{
        font-size: 44px;
          color: #333;
          margin-bottom: 10px;
          font-family: 'Georgia', serif;
          transition: color 0.2s;
        
    }

       .content-heading:hover {
          color: #007BFF;
       }

       .content-paragraph {
          font-size: 16px;
          color: #666;
          line-height: 1.6;
          transition: color 0.2s;
       }
       .content-paragraph-s {
        font-size: 46px;
          color: #666;
          line-height: 1.6;
          transition: color 0.2s;
       }
       .content-paragraph-p {
        font-size: 38px;
          color: #666;
          line-height: 1.6;
          transition: color 0.2s;
       }
       

       .content-paragraph:hover {
          color: #555;
       }

       .list-item {
          list-style: none;
          padding: 0;
          margin: 0;
       }

       .sub-list-holder {   
          margin-bottom: 10px;
       }

       .list-item-container {
          display: flex;
          align-items: center;
       }

       .list-icon {
          display: inline-block;
          margin-right: 15px;
       }

       .tick-icon {
          width: 20px;
          height: 20px;
          background: url('data:image/svg+xml;utf8,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="green"><path d="M9 19l-7-7 1.41-1.41L9 16.17l13.59-13.59L24 5z"/></svg>') no-repeat center center;
          background-size: contain;
          margin-right: 15px;
       }

       .low-cost-item {
          margin-left: auto;
       }

       .big-image-container {
          display: flex;
          flex-wrap: wrap;
          justify-content: center;
       }

       .big-image-container img {
          margin: 10px;
          border-radius: 8px;
          box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
       }

       .cta-button {
          background-color: #007BFF;
          color: #fff;
          padding: 10px 20px;
          border: none;
          border-radius: 15px;
          cursor: pointer;
       }

       .cta-button:hover {
          background-color: #0069d9;
       }
       .banner-container {
    display: flex;
    justify-content: space-around;
    margin: 50px 0;
    padding-left: 37px;
    padding-right: 37px;
}

.banner-item {
    padding: 40px;
    border-radius: 10px;
    width: 18%; /* Adjust the width as needed */
    box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
    transition: transform 0.2s;
}

.banner-item:hover {
    transform: translateY(-5px);
}

.banner-secondary-bg {
    background-color: #343a40; /* Example background color */
}

.text-white {
    color: white;
}

/* Font styles for headings */
.banner-item h2 {
    font-size: 1.9em; /* Adjust the size as needed */
    font-weight: bold; /* Set the font weight */
    margin-bottom: 10px; /* Space below the heading */
}

/* Font styles for paragraphs */
.banner-item p {
    font-size: 1.6em; /* Adjust the size as needed */
    line-height: 1.5; /* Space between lines */
    margin: 0; /* Remove default margin */
}
       
    </style>
</head>
<body class="blur">
<div class="content-container">
  <img src="images/images.png" alt="Description of Image" class="content-image" style="width: 700px; height: auto;">
  <div>
    <h1 class="content-heading">Provide best Services for you</h1>
    <p class="content-paragraph">Provide the best web development services for our client with their satisfaction!</p>
    <p class="content-paragraph">We are committed to delivering top-tier web development services that not only meet but exceed our clients' expectations, ensuring their utmost satisfaction.</p>
    <ul class="list-item">
        <li class="sub-list-holder">
            <ul class="sub-list-item">
                <li class="list-item-container">
                    <div class="list-icon tick-icon"></div>
                    <div class="list-text">
                        <span>Expert Team</span>
                    
                </li>
            </ul>
        </li>
        <li class="sub-list-holder">
            <ul class="sub-list-item">
                <li class="list-item-container">
                    <div class="list-icon tick-icon"></div>
                    <div class="list-text">
                        <span>All time Support</span>
                    </div>
                </li>
            </ul>
        </li>
    </ul>
    <button class="cta-button">Get Started</button>
  </div>
</div>

<div class="content-container">
  <div>
    <h1 class="content-heading-s">Services</h1>
    <p class="content-paragraph-s">Provide Unique & Quality Service!</p>
    <p class="content-paragraph-p">We provide high-quality web development services, crafting unique, reliable, and innovative websites tailored to your needs. Let us help you build a strong online presence!</p>

    <a href="work.php" style="position: relative; display: inline-block;">
      <img src="images/landing image.jpeg" alt="Description of Image 1" class="content-image">
      <span class="overlay-text"><h1>Landing Page</h1></span>
    </a>
    
    <a href="work.php" style="position: relative; display: inline-block;">
      <img src="images/customwebs.png" alt="Description of Image 2" class="content-image">
      <span class="overlay-text"><h1>Custom Website</h1></span>
    </a>
    
    <a href="work.php" style="position: relative; display: inline-block;">
      <img src="images/website Development.avif" alt="Description of Image 2" class="content-image">
      <span class="overlay-text"><h1>Website Development</h1></span>
    </a>

    <a href="work.php" style="position: relative; display: inline-block;">
      <img src="images/cms.jpg" alt="Description of Image 2" class="content-image">
      <span class="overlay-text"><h1>CMS</h1></span>
    </a>
    
    
  </div>
</div>

<style>
.content-container {
    text-align: center;
}

.content-image {
    height: 360px; /* Set a fixed height for the images */
    width: auto; /* Maintain aspect ratio */
    max-width: 90%; /* Ensure the image does not overflow its container */
    transition: transform 0.4s; /* Smooth scaling effect */
}

.overlay-text {
    position: absolute;
    top: 45%;
    left: 45%;
    transform: translate(-50%, -50%);
    color: greenyellow;
    font-size: 24px;
    display: none; /* Hide the text by default */
    text-align: center;
}

a {
    position: relative;
    display: inline-block;
}

a:hover .overlay-text {
    display: block; /* Show the text on hover */
}

a:hover .content-image {
    transform: scale(1.05); /* Slightly scale the image on hover */
}
</style>

<div class="banner-container">
    <div class="banner-item banner-secondary-bg text-white">
        <h2>Meeting with Clients</h2>
        <p>We believe great projects start with great conversations. Our client meetings focus on understanding your vision and goals.</p>
    </div>
    <div class="banner-item banner-secondary-bg text-white">
        <h2>Project Planning</h2>
        <p>We prioritize strategic project planning to ensure seamless workflows, timely milestones, and a final product that exceeds expectations.</p>
    </div>
    <div class="banner-item banner-secondary-bg text-white">
        <h2>Hand over Project</h2>
        <p>Handover is more than just delivery; we provide guidance and training to empower you to manage your new website effectively.</p>
    </div>
</div>

<script>
        window.onload = function() {
            setTimeout(function() {
                document.body.classList.remove('blur'); // Remove the blur class after 2 seconds
            }, 2000); // Adjust the delay time as needed (2000ms = 2 seconds)
        };
    </script>
 
</body>
</html>

<?php
include 'footer.php';
?>