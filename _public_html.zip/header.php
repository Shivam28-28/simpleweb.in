<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Header Example</title>
    <style>
        /* Basic Reset */
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f4f4f4; /* Light background for contrast */
        }

        /* Header Styles */
        header {
    display: flex;
    align-items: center;
    background: linear-gradient(179deg, #578766fa, #ffaeaef2); /* Use 'background' instead of 'background-color' for gradient */
    color: #333; /* Dark text for contrast */
    padding: 20px 40px;
    box-shadow: 0 2px 10px rgba(0, 0, 0, 0.3); /* Deeper shadow for depth */
    backdrop-filter: blur(5px); /* Blurry background effect */
    position: ; /* Make the header fixed */
    top: 0; /* Position it at the top of the viewport */
    left: 0; /* Align to the left */
    right: 0; /* Align to the right */
    z-index: 1000; /* Ensure it appears above other elements */
}

        .logo img {
            height: 80px; /* Adjust logo size */
            width: auto; /* Maintain aspect ratio */
        }

        nav {
            display: flex;
            gap: 40px;
            margin-left: auto; /* Pushes the nav to the right */
            position: relative; /* Position for dropdown */
        }

        nav a {
            color: #2a6400b8; /* Change link color to white */
            text-decoration: none;
            font-size: 20px;
            padding: 10px 15px; /* Add padding for better click area */
            border-radius: 5px; /* Rounded corners */
            transition: background-color 0.3s, color 0.3s; /* Smooth transition */
            backdrop-filter: blur(5px); /* Blurry background effect for links */
        }

        nav a:hover {
            background-color: rgba(255, 255, 255, 0.3); /* Lighten background on hover */
            color: #006400; /* Dark green text on hover */
        }

        /* Dropdown Menu Styles */
        .drop-menu {
            display: none; /* Hide the dropdown by default */
            position: absolute; /* Position it below the main link */
            background-color: rgba(255, 255, 255, 0.9); /* White background for dropdown with transparency */
            border: 1px solid #ccc; /* Light border for the dropdown */
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2); /* Add some shadow */
            z-index: 1000; /* Ensure it appears above other elements */
            list-style-type: none; /* Remove bullet points */
            padding: 0; /* Remove padding */
            margin: 0; /* Remove margin */
            border-radius: 8px; /* Rounded corners for dropdown */
            top: 100%; /* Position it below the parent */
            left: 0; /* Align to the left of the parent */
            min-width: 200px; /* Minimum width for dropdown */
        }

        /* Dropdown Item Styles */
        .drop-menu li {
            border-bottom: 1px solid #eee; /* Light border between items */
        }

        .drop-menu li:last-child {
            border-bottom: none; /* Remove border for last item */
        }

        .drop-menu li a {
            display: block; /* Make the link fill the entire list item */
            padding: 15px 20px; /* Padding for dropdown items */
            color: #333; /* Text color for dropdown links */
            transition: background-color 0.3s; /* Smooth transition */
        }

        .drop-menu li a:hover {
            background-color: #f0f0f0; /* Light grey background on hover */
        }

        /* Show dropdown when hovering over the "Services" link */
        nav a:hover + .drop-menu,
        nav .drop-menu:hover {
            display: block; /* Show the dropdown */
        }

        .contact-link {
            color: #216400a8; /* Change text color for contact link */
            text-decoration: none; /* No underline */
            font-size: 25px; /* Font size */
            padding: 10px 15px; /* Padding */
            border-radius: 5px; /* Rounded corners */
            transition: background-color 0.3s, color 0.3s; /* Smooth transition */
            background-color: transparent; /* Ensure the background is transparent by default */
            backdrop-filter: blur(5px); /* Blurry background effect for contact link }
        
        .contact-link:hover {
            background-color: rgba(255, 255, 255, 0.3); /* Lighten background on hover */
            color: #006400; /* Dark green text on hover */
        }
    </style>
</head>
<body>

<header>
    <div class="logo">
        <img src="images/logo shivam.jpeg" alt="Shivam .Co Logo">
    </div>
    <nav>
        <a href="#">Services</a>
        <ul class="drop-menu" aria-label="Services Dropdown">
            <li><a class="dropdown-item" href="web.development.php">Web Development</a></li>
            <!-- <li><a class="dropdown-item" href="whatsapp.php">WhatsApp</a></li> -->
        </ul>   
    </nav>
    
    <a href="contact.php" class="contact-link">Contact</a>
</header>

</body>
</html>