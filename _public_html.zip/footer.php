<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Footer Example</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <style>
        body {
            margin: 0;
            font-family: Arial, sans-serif;
        }

        footer {
            background: linear-gradient(135deg, #2c3e50, #4ca1af);
            color: white;
            padding: 40px 20px;
            text-align: center;
        }

        .footer-container {
            display: flex;
            justify-content: space-around;
            flex-wrap: wrap;
            max-width: 1200px;
            margin: auto;
        }

        .footer-links, .footer-contact, .footer-social {
            flex: 1;
            min-width: 300px;
            margin: 20px;
            padding: 20px;
            border-radius: 8px;
            background-color: rgba(255, 255, 255, 0.1); /* Semi-transparent background */
            transition: transform 0.3s, background-color 0.3s;
        }

        .footer-links h4, .footer-contact h4 {
            color: #ffcc00;
            margin-bottom: 15px;
        }

        .footer-links ul {
            list-style: none;
            padding: 0;
        }

        .footer-links ul li {
            margin: 10px 0;
        }

        .footer-links a {
            text-decoration: none;
            color: #ffcc00;
            transition: color 0.3s;
        }

        .footer-links a:hover {
            color: #00BFFF;
        }

        .footer-social {
            display: flex;
            justify-content: center;
            align-items: center;
        }

        .footer-social a {
            margin: 0 10px;
            color: #ffcc00;
            text-decoration: none;
            font-size: 24px;
            transition: transform 0.3s, color 0.3s;
        }

        .footer-social a:hover {
            color: #00BFFF;
            transform: scale(1.2); /* Slightly scale up icons on hover */
        }

        .footer-links:hover, .footer-contact:hover {
            background-color: rgba(255, 255, 255, 0.2); /* Darker background on hover */
            transform: translateY(-5px); /* Slight lift effect */
        }

        .footer-bottom {
            margin-top: 20px;
            font-size: 14px;
            opacity: 0.8; /* Slightly transparent */
        }
        .footer-address {
    flex: 1;
    min-width: 200px;
    margin: 10px;
    padding: 20px;
    border-radius: 8px;
    background-color: rgba(255, 255, 255, 0.1); /* Semi-transparent background */
    transition: transform 0.3s, background-color 0.3s;
}

.footer-address h4 {
    color: #ffcc00;
    margin-bottom: 15px;
}

.footer-address p {
    color: white; /* Make the text color white for better visibility */
    line-height: 1.5; /* Improved line spacing */
}

.footer-address:hover {
    background-color: rgba(255, 255, 255, 0.2); /* Darker background on hover */
    transform: translateY(-5px); /* Slight lift effect */
}
.footer-bubbles {
    position: relative;
    overflow: hidden; /* To hide bubbles that go out of the footer */
}

.bubble {
    position: absolute;
    bottom: -50px; /* Start below the footer */
    border-radius: 50%;
    opacity: 0.7;
    animation: rise 5s infinite;
}

@keyframes rise {
    0% {
        transform: translateY(0);
        opacity: 0.7;
    }
    100% {
        transform: translateY(-100px); /* Move up */
        opacity: 0; /* Fade out */
    }
}

/* Add random bubble sizes and positions */
.bubble:nth-child(1) {
    width: 20px;
    height: 20px;
    left: 10%;
    animation-duration: 6s;
}

.bubble:nth-child(2) {
    width: 30px;
    height: 30px;
    left: 30%;
    animation-duration: 5s;
}

.bubble:nth-child(3) {
    width: 25px;
    height: 25px;
    left: 50%;
    animation-duration: 7s;
}

.bubble:nth-child(4) {
    width: 15px;
    height: 15px;
    left: 70%;
    animation-duration: 6.5s;
}

.bubble:nth-child(5) {
    width: 35px;
    height: 35px;
    left: 80%;
    animation-duration: 4.5s;
}
    </style>
</head>
<body>

<footer>
    <div class="footer-bubbles">
        <div class="bubble"></div>
        <div class="bubble"></div>
        <div class="bubble"></div>
        <div class="bubble"></div>
        <div class="bubble"></div>
    </div>
    <div class="footer-container">
        <div class="footer-links">
            <h4>Quick Links</h4>
            <ul>
                <li><a href="work.php">Work</a></li>
                <li><a href="contact.php">Contact</a></li>
            </ul>
        </div>

        <div class="footer-links">
            <h4>Work</h4>
            <ul>
                <li><a href="work.php">Landing page</a></li>
                <li><a href="work.php">Custom Website</a></li>
                <li><a href="work.php">Web Development</a></li>
                <li><a href="work.php">CMS</a></li>
            </ul>
        </div>

        <div class="footer-contact">
            <h4>Contact Us</h4>
            <p>Email: shivamsharmabsr456@gmail.com</p>
            <p>Phone: +91 936 801 7732 <br> | +91 824 907 0953 <br> | +91 91663 44811</p>
        </div>
        <div class="footer-address">
            <h4>Address</h4>
            <p>B 801 Arise Antlatis,Near Parmeshwar 07, Godrej Garden City,
            Jagatpur, Ahmedabad - 382401, Gujarat, India</p>
        </div>

        <div class="footer-social">
            <a href="https://www.facebook.com/" class="fab fa-facebook-f"></a>
            <a href="#" class="fab fa-twitter"></a>
            <a href="https://www.instagram.com/" class="fab fa-instagram"></a>
            <a href="#" class="fab fa-linkedin-in"></a>
        </div>
    </div>

    <div class="footer-bottom">
        <p>&copy; 2024 Shivam Website. All Rights Reserved.</p>
    </div>
</footer>

</body>
</html>